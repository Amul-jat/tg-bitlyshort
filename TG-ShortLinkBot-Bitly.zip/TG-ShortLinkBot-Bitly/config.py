from os import environ

API_ID = int(environ.get('API_ID'))
API_HASH = environ.get('API_HASH')
BOT_TOKEN = environ.get('BOT_TOKEN')
BITLY_KEY = environ.get('BITLY_KEY')
OWNER = environ.get('OWNER','BotDunia')
